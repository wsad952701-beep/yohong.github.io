/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // R3F + Drei 在 SSR 環境下需要 transpile，避免 ESM 衝突
  transpilePackages: ["three", "@react-three/fiber", "@react-three/drei", "@react-three/postprocessing"],
  experimental: {
    optimizePackageImports: ["three", "@react-three/drei", "gsap"],
  },
  webpack: (config) => {
    // 允許在 import 中直接讀入 .glsl / .vs / .fs / .vert / .frag 為字串
    config.module.rules.push({
      test: /\.(glsl|vs|fs|vert|frag)$/,
      type: "asset/source",
    });
    return config;
  },
};

export default nextConfig;
