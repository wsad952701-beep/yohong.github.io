"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";

import { usePerformance } from "./PerformanceGuard";

/* ---------------------------------------------------------------------
   Cursor
   ---------------------------------------------------------------------
   雙層圓環自定義游標：
     • 內核：精準位置，瞬間跟隨
     • 外環：以 GSAP 滯後跟隨，hover 互動元素時放大、變色
   觸控裝置自動隱藏。
   --------------------------------------------------------------------- */

export default function Cursor() {
  const { isTouch } = usePerformance();
  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isTouch) return;

    const move = (e: MouseEvent) => {
      gsap.to(dotRef.current, {
        x: e.clientX,
        y: e.clientY,
        duration: 0.05,
        ease: "power3.out",
      });
      gsap.to(ringRef.current, {
        x: e.clientX,
        y: e.clientY,
        duration: 0.55,
        ease: "power3.out",
      });
    };

    const onEnter = () => {
      gsap.to(ringRef.current, { scale: 1.8, opacity: 0.8, duration: 0.4, ease: "power3.out" });
    };
    const onLeave = () => {
      gsap.to(ringRef.current, { scale: 1, opacity: 0.4, duration: 0.4, ease: "power3.out" });
    };

    window.addEventListener("mousemove", move);
    document.querySelectorAll('a, button, [role="button"], .cursor-target').forEach((el) => {
      el.addEventListener("mouseenter", onEnter);
      el.addEventListener("mouseleave", onLeave);
    });

    return () => {
      window.removeEventListener("mousemove", move);
      document.querySelectorAll('a, button, [role="button"], .cursor-target').forEach((el) => {
        el.removeEventListener("mouseenter", onEnter);
        el.removeEventListener("mouseleave", onLeave);
      });
    };
  }, [isTouch]);

  if (isTouch) return null;

  return (
    <>
      <div
        ref={ringRef}
        className="pointer-events-none fixed top-0 left-0 z-[100] -translate-x-1/2 -translate-y-1/2 mix-blend-difference"
        style={{ opacity: 0.4 }}
      >
        <div className="h-9 w-9 rounded-full border border-white/70" />
      </div>
      <div
        ref={dotRef}
        className="pointer-events-none fixed top-0 left-0 z-[100] -translate-x-1/2 -translate-y-1/2 mix-blend-difference"
      >
        <div className="h-1.5 w-1.5 rounded-full bg-white" />
      </div>
    </>
  );
}
