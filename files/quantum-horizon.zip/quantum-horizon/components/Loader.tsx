"use client";

import { useEffect, useState } from "react";

/* ---------------------------------------------------------------------
   Loader
   ---------------------------------------------------------------------
   1.8 秒的進場動畫：標題逐字浮現 + 進度條收闔。
   --------------------------------------------------------------------- */

export default function Loader() {
  const [exit, setExit] = useState(false);
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setExit(true), 1700);
    const t2 = setTimeout(() => setHidden(true), 2600);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  if (hidden) return null;

  const title = "量子境界";

  return (
    <div
      className={`fixed inset-0 z-[200] flex items-center justify-center bg-void-950 transition-all duration-[900ms] ease-[cubic-bezier(0.7,0,0.3,1)] ${
        exit ? "opacity-0 pointer-events-none translate-y-[-2vh]" : "opacity-100"
      }`}
    >
      {/* 背景脈衝 */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[80vh] w-[80vh] rounded-full bg-aurora-cyan/10 blur-[120px] animate-breath" />
        <div className="absolute left-[60%] top-[40%] h-[40vh] w-[40vh] rounded-full bg-aurora-plasma/10 blur-[100px] animate-drift-slow" />
      </div>

      <div className="relative flex flex-col items-center gap-12">
        {/* 商標：旋轉光環 */}
        <div className="relative h-16 w-16">
          <span className="absolute inset-0 rounded-full border border-white/15" />
          <span className="absolute inset-1 rounded-full border border-aurora-cyan/40 animate-spin" style={{ animationDuration: "3s" }} />
          <span className="absolute inset-3 rounded-full border border-aurora-plasma/40 animate-spin" style={{ animationDuration: "5s", animationDirection: "reverse" }} />
          <span className="absolute inset-5 rounded-full bg-aurora-cyan animate-glow-pulse" />
        </div>

        {/* 標題 */}
        <h1 className="font-display title-major text-5xl md:text-6xl text-white char-stagger">
          {title.split("").map((c, i) => (
            <span key={i} style={{ animationDelay: `${i * 100 + 200}ms` }}>
              {c}
            </span>
          ))}
        </h1>

        {/* 副標 */}
        <div className="flex items-center gap-3 font-mono tabular text-[10px] tracking-[0.4em] text-white/45 uppercase">
          <span className="block h-px w-8 bg-white/30" />
          <span>Synchronizing&nbsp;Spatial&nbsp;Layer</span>
          <span className="block h-px w-8 bg-white/30" />
        </div>

        {/* 進度條 */}
        <div className="relative h-px w-56 overflow-hidden bg-white/10">
          <div
            className="absolute inset-y-0 left-0 bg-gradient-to-r from-aurora-cyan via-aurora-plasma to-aurora-ember"
            style={{
              animation: "loadbar 1.6s cubic-bezier(0.7,0,0.3,1) forwards",
            }}
          />
        </div>
        <style jsx>{`
          @keyframes loadbar {
            0%   { width: 0%; }
            100% { width: 100%; }
          }
        `}</style>
      </div>
    </div>
  );
}
