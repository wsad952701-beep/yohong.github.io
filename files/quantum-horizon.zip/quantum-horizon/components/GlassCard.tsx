"use client";

import { useRef, useState } from "react";
import gsap from "gsap";

/* ---------------------------------------------------------------------
   GlassCard
   ---------------------------------------------------------------------
   Apple Vision Pro 風格的浮空玻璃卡。
   滑鼠懸停時：
     - 卡片以滑鼠位置作 3D tilt（perspective）
     - 內部高光跟隨游標
     - GSAP 處理 spring-like 衰減
   --------------------------------------------------------------------- */

interface GlassCardProps {
  index: string;
  title: string;
  description: string;
  meta?: string;
  className?: string;
}

export default function GlassCard({
  index,
  title,
  description,
  meta,
  className = "",
}: GlassCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const glowRef = useRef<HTMLDivElement>(null);
  const [isHover, setIsHover] = useState(false);

  const handleMove = (e: React.MouseEvent) => {
    if (!cardRef.current || !glowRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const cx = rect.width / 2;
    const cy = rect.height / 2;

    const rotX = ((y - cy) / cy) * -6;
    const rotY = ((x - cx) / cx) * 6;

    gsap.to(cardRef.current, {
      rotateX: rotX,
      rotateY: rotY,
      duration: 0.8,
      ease: "power3.out",
      transformPerspective: 1000,
    });

    glowRef.current.style.background = `radial-gradient(circle at ${x}px ${y}px, rgba(127,232,255,0.18), transparent 50%)`;
  };

  const handleLeave = () => {
    if (!cardRef.current) return;
    gsap.to(cardRef.current, {
      rotateX: 0,
      rotateY: 0,
      duration: 1.2,
      ease: "elastic.out(1, 0.4)",
    });
    setIsHover(false);
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMove}
      onMouseEnter={() => setIsHover(true)}
      onMouseLeave={handleLeave}
      className={`group relative will-change-transform [transform-style:preserve-3d] ${className}`}
    >
      <div className="glass-pane-strong glass-rim relative overflow-hidden p-7 md:p-8">
        {/* 動態光暈 */}
        <div
          ref={glowRef}
          className="pointer-events-none absolute inset-0 transition-opacity duration-500"
          style={{ opacity: isHover ? 1 : 0 }}
        />

        {/* 編號 */}
        <div className="flex items-center justify-between mb-7">
          <span className="font-mono tabular text-[11px] uppercase tracking-[0.4em] text-white/40">
            {index}
          </span>
          {meta && (
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-aurora-cyan/70">
              {meta}
            </span>
          )}
        </div>

        {/* 標題 */}
        <h3 className="font-display text-[26px] md:text-[30px] leading-[1.15] tracking-tight text-white mb-4">
          {title}
        </h3>

        {/* 說明 */}
        <p className="font-sans text-[14px] md:text-[15px] leading-[1.75] text-white/65">
          {description}
        </p>

        {/* 角點裝飾 */}
        <span className="absolute top-3 right-3 h-2 w-2 rounded-full bg-aurora-cyan opacity-60 group-hover:opacity-100 transition-opacity" />
        <span className="absolute bottom-3 left-3 font-mono text-[9px] tracking-[0.3em] text-white/30">
          QH ─ {index}
        </span>
      </div>
    </div>
  );
}
