"use client";

import { useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";

import vertexShader from "./shaders/nebula.vert";
import fragmentShader from "./shaders/nebula.frag";

/* ---------------------------------------------------------------------
   NebulaBackground
   ---------------------------------------------------------------------
   位於 NDC z=0.999 的全屏四邊形，永遠在所有 3D 物件後方，
   透過 FBM 噪聲生成隨章節變色的雲氣。
   --------------------------------------------------------------------- */

interface NebulaProps {
  scrollRef: React.MutableRefObject<{ progress: number }>;
}

export default function NebulaBackground({ scrollRef }: NebulaProps) {
  const matRef = useRef<THREE.ShaderMaterial>(null);
  const { size } = useThree();

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uScroll: { value: 0 },
      uResolution: { value: new THREE.Vector2(size.width, size.height) },
      uIntensity: { value: 1.0 },
    }),
    [size.width, size.height]
  );

  useFrame((_, delta) => {
    if (!matRef.current) return;
    const u = matRef.current.uniforms;
    u.uTime.value += delta;
    u.uScroll.value = THREE.MathUtils.lerp(
      u.uScroll.value,
      scrollRef.current.progress,
      0.04
    );
    u.uResolution.value.set(size.width, size.height);
  });

  return (
    <mesh frustumCulled={false} renderOrder={-100}>
      <planeGeometry args={[2, 2]} />
      <shaderMaterial
        ref={matRef}
        uniforms={uniforms}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        depthTest={false}
        depthWrite={false}
      />
    </mesh>
  );
}
