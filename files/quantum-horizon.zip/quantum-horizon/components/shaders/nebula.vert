// =====================================================================
// Nebula Background — Vertex Shader (full-screen quad)
// =====================================================================
varying vec2 vUv;

void main() {
  vUv = uv;
  gl_Position = vec4(position.xy, 0.999, 1.0);
}
