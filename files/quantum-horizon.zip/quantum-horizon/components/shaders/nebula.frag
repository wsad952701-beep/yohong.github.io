// =====================================================================
// Nebula Background — Fragment Shader
// ---------------------------------------------------------------------
// 用 FBM (Fractal Brownian Motion) 生成有層次的雲氣，
// 顏色依章節進度從深青 → 紫紅 → 琥珀漸變。
// =====================================================================

precision highp float;

uniform float uTime;
uniform float uScroll;
uniform vec2  uResolution;
uniform float uIntensity;

varying vec2 vUv;

// hash & 2D simplex
vec2 hash22(vec2 p) {
  p = vec2(dot(p, vec2(127.1, 311.7)),
           dot(p, vec2(269.5, 183.3)));
  return -1.0 + 2.0 * fract(sin(p) * 43758.5453123);
}

float noise2D(vec2 p) {
  const float K1 = 0.366025404;
  const float K2 = 0.211324865;
  vec2 i = floor(p + (p.x + p.y) * K1);
  vec2 a = p - i + (i.x + i.y) * K2;
  vec2 o = (a.x > a.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
  vec2 b = a - o + K2;
  vec2 c = a - 1.0 + 2.0 * K2;
  vec3 h = max(0.5 - vec3(dot(a,a), dot(b,b), dot(c,c)), 0.0);
  vec3 n = h*h*h*h * vec3(
    dot(a, hash22(i)),
    dot(b, hash22(i + o)),
    dot(c, hash22(i + 1.0))
  );
  return dot(n, vec3(70.0));
}

float fbm(vec2 p) {
  float v = 0.0;
  float amp = 0.5;
  for (int i = 0; i < 5; i++) {
    v += amp * noise2D(p);
    p *= 2.02;
    amp *= 0.5;
  }
  return v;
}

void main() {
  vec2 uv = vUv;
  // 修正寬高比
  vec2 p = (uv - 0.5) * vec2(uResolution.x / uResolution.y, 1.0) * 1.6;

  float t = uTime * 0.025;
  vec2 q = vec2(fbm(p + t), fbm(p - t + 5.2));
  vec2 r = vec2(fbm(p + 1.5 * q + t * 0.5 + vec2(1.7, 9.2)),
                fbm(p + 1.5 * q + t * 0.4 + vec2(8.3, 2.8)));
  float f = fbm(p + 1.4 * r);

  // 章節色彩
  vec3 deep = vec3(0.012, 0.020, 0.043);     // 深沉午夜
  vec3 cyan = vec3(0.122, 0.294, 0.541);     // 量子青
  vec3 plasma = vec3(0.380, 0.196, 0.561);   // 電漿紫
  vec3 ember  = vec3(0.561, 0.310, 0.137);   // 暖琥珀

  vec3 c1 = mix(cyan, plasma, smoothstep(0.2, 0.7, uScroll));
  vec3 c2 = mix(c1, ember, smoothstep(0.65, 1.0, uScroll));

  vec3 col = mix(deep, c2, clamp(f * 1.4 + 0.3, 0.0, 1.0));

  // 圓形漸暈（vignette）
  float vignette = smoothstep(1.1, 0.3, length(uv - 0.5) * 1.4);
  col *= vignette * 0.8 + 0.2;

  // 整體強度
  col *= uIntensity;

  gl_FragColor = vec4(col, 1.0);
}
