"use client";

import { useEffect, useState } from "react";

/* ---------------------------------------------------------------------
   Navigation — 漂浮的玻璃導覽列
   --------------------------------------------------------------------- */

const sections = [
  { id: "chapter-0", label: "入境", index: "I" },
  { id: "chapter-1", label: "晶核", index: "II" },
  { id: "chapter-2", label: "網絡", index: "III" },
  { id: "chapter-3", label: "未來", index: "IV" },
];

export default function Navigation() {
  const [active, setActive] = useState(0);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 60);

      // 找出最接近視窗中心的章節
      const centers = sections.map((s) => {
        const el = document.getElementById(s.id);
        if (!el) return Infinity;
        const r = el.getBoundingClientRect();
        return Math.abs(r.top + r.height / 2 - window.innerHeight / 2);
      });
      const min = Math.min(...centers);
      setActive(centers.indexOf(min));
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 transition-all duration-700 ease-[cubic-bezier(0.16,1,0.3,1)] ${
        scrolled ? "scale-95 opacity-95" : "scale-100"
      }`}
    >
      <div className="glass-pane glass-rim flex items-center gap-1 px-2 py-1.5 sm:px-3 sm:py-2">
        {/* 品牌標 */}
        <div className="hidden sm:flex items-center gap-2.5 px-3 mr-1 border-r border-white/10">
          <div className="relative h-2 w-2">
            <span className="absolute inset-0 rounded-full bg-aurora-cyan animate-breath" />
            <span className="absolute inset-0 rounded-full bg-aurora-cyan blur-sm opacity-60" />
          </div>
          <span className="font-display text-[13px] tracking-[0.3em] text-white/85">
            QUANTUM&nbsp;HORIZON
          </span>
        </div>

        {/* 章節 pill */}
        <ul className="flex items-center gap-0.5">
          {sections.map((s, i) => (
            <li key={s.id}>
              <a
                href={`#${s.id}`}
                className={`relative flex items-center gap-2 rounded-full px-3 py-1.5 text-[11px] uppercase tracking-[0.18em] transition-colors duration-500 ${
                  active === i
                    ? "text-white"
                    : "text-white/45 hover:text-white/75"
                }`}
              >
                {active === i && (
                  <span className="absolute inset-0 rounded-full bg-white/8 backdrop-blur-md ring-1 ring-white/15" />
                )}
                <span className="relative font-mono tabular text-[10px] opacity-70">
                  {s.index}
                </span>
                <span className="relative font-display tracking-[0.32em]">{s.label}</span>
              </a>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <a
          href="#chapter-3"
          className="hidden md:inline-flex items-center gap-1.5 ml-2 rounded-full bg-white/[0.06] hover:bg-white/[0.12] active:bg-white/[0.18] border border-white/10 px-3.5 py-1.5 text-[11px] uppercase tracking-[0.22em] text-white/85 transition-all duration-300"
        >
          <span>啟動體驗</span>
          <span aria-hidden>→</span>
        </a>
      </div>
    </nav>
  );
}
