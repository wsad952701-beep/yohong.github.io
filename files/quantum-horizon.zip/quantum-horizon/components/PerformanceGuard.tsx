"use client";

import { createContext, useContext, useEffect, useState } from "react";

/* ---------------------------------------------------------------------
   PerformanceGuard
   ---------------------------------------------------------------------
   依據裝置記憶體、CPU 核心數、GPU 字串、是否觸控，判斷渲染等級：
     • "ultra"   — 桌機高階獨顯，可開全特效（粒子 80k、後製全開）
     • "high"    — 桌機中階，粒子 40k、後製保留 bloom + chromatic
     • "balanced"— 主流筆電 / iPad，粒子 18k，僅保留 bloom
     • "lite"    — 手機 / 弱裝置，粒子 6k，關閉後製、降低 DPR
   --------------------------------------------------------------------- */

export type PerfTier = "ultra" | "high" | "balanced" | "lite";

interface PerfState {
  tier: PerfTier;
  isTouch: boolean;
  prefersReducedMotion: boolean;
  dpr: [number, number];
}

const PerfContext = createContext<PerfState>({
  tier: "balanced",
  isTouch: false,
  prefersReducedMotion: false,
  dpr: [1, 1.5],
});

function detectTier(): PerfTier {
  if (typeof window === "undefined") return "balanced";

  const isMobile = /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
  // @ts-expect-error - navigator.deviceMemory 為實驗性 API
  const memory: number = navigator.deviceMemory || 4;
  const cores: number = navigator.hardwareConcurrency || 4;

  // 嘗試讀取 GPU renderer 字串
  let gpu = "";
  try {
    const canvas = document.createElement("canvas");
    const gl = canvas.getContext("webgl2") || canvas.getContext("webgl");
    if (gl) {
      const dbg = gl.getExtension("WEBGL_debug_renderer_info");
      if (dbg) {
        gpu = gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) as string;
      }
    }
  } catch {
    /* noop */
  }

  if (isMobile) return memory >= 6 && cores >= 6 ? "balanced" : "lite";

  // 桌面分級
  const lowerGpu = gpu.toLowerCase();
  const isHighGpu = /rtx|radeon rx|m1 max|m1 ultra|m2 max|m2 ultra|m3 max|m3 ultra|m4|apple gpu/.test(lowerGpu);
  const isMidGpu = /gtx|radeon|iris xe|m1|m2|m3|apple/.test(lowerGpu);

  if (memory >= 8 && cores >= 8 && isHighGpu) return "ultra";
  if (memory >= 8 && cores >= 6 && (isHighGpu || isMidGpu)) return "high";
  return "balanced";
}

export function PerformanceGuardProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [state, setState] = useState<PerfState>({
    tier: "balanced",
    isTouch: false,
    prefersReducedMotion: false,
    dpr: [1, 1.5],
  });

  useEffect(() => {
    const tier = detectTier();
    const isTouch = window.matchMedia("(hover: none) and (pointer: coarse)").matches;
    const prefersReducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    const dprMap: Record<PerfTier, [number, number]> = {
      ultra:    [1, 2],
      high:     [1, 1.75],
      balanced: [1, 1.5],
      lite:     [0.75, 1],
    };

    setState({ tier, isTouch, prefersReducedMotion, dpr: dprMap[tier] });

    if (process.env.NODE_ENV === "development") {
      // eslint-disable-next-line no-console
      console.info("[Perf] tier:", tier, "| touch:", isTouch);
    }
  }, []);

  return <PerfContext.Provider value={state}>{children}</PerfContext.Provider>;
}

export function usePerformance() {
  return useContext(PerfContext);
}
