"use client";

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { MeshTransmissionMaterial, Float, Icosahedron } from "@react-three/drei";
import * as THREE from "three";

import { usePerformance } from "./PerformanceGuard";

/* ---------------------------------------------------------------------
   CrystalCore
   ---------------------------------------------------------------------
   一顆懸浮的折射晶體，作為第二章節「核心」的主角。
   使用 Drei 的 MeshTransmissionMaterial（在 R3F 中堪比 Vision Pro 的玻璃）。
   --------------------------------------------------------------------- */

interface CrystalCoreProps {
  scrollRef: React.MutableRefObject<{ progress: number }>;
}

export default function CrystalCore({ scrollRef }: CrystalCoreProps) {
  const { tier } = usePerformance();
  const groupRef = useRef<THREE.Group>(null);
  const innerRef = useRef<THREE.Mesh>(null);

  // 高階裝置才開啟厚重的 transmission samples
  const samples = tier === "ultra" ? 16 : tier === "high" ? 10 : tier === "balanced" ? 6 : 3;
  const resolution = tier === "ultra" ? 1024 : tier === "high" ? 512 : 256;

  useFrame((state, delta) => {
    if (!groupRef.current || !innerRef.current) return;

    const t = state.clock.elapsedTime;
    const scroll = scrollRef.current.progress;

    // 緩慢自轉
    groupRef.current.rotation.y += delta * 0.18;
    groupRef.current.rotation.x = Math.sin(t * 0.3) * 0.12;

    // 內核以反向旋轉
    innerRef.current.rotation.y -= delta * 0.4;
    innerRef.current.rotation.z += delta * 0.12;

    // 章節 1（晶核）時呈現，其它章節縮小消失
    const visibility = Math.exp(-Math.pow((scroll - 0.33) * 5.0, 2));
    const targetScale = 0.4 + visibility * 0.9;
    groupRef.current.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), 0.06);
  });

  return (
    <Float speed={1.2} rotationIntensity={0.4} floatIntensity={0.6}>
      <group ref={groupRef} position={[0, 0, 0]}>
        {/* 外殼：高度透射 */}
        <Icosahedron args={[1.4, 4]}>
          <MeshTransmissionMaterial
            backside
            samples={samples}
            resolution={resolution}
            transmission={1}
            roughness={0.05}
            thickness={1.2}
            ior={1.4}
            chromaticAberration={0.15}
            anisotropy={0.3}
            distortion={0.4}
            distortionScale={0.5}
            temporalDistortion={0.15}
            color="#A8D5FF"
            attenuationColor="#7FE8FF"
            attenuationDistance={1.2}
          />
        </Icosahedron>

        {/* 內核：發光小球 */}
        <mesh ref={innerRef}>
          <icosahedronGeometry args={[0.5, 2]} />
          <meshBasicMaterial color="#C77DFF" toneMapped={false} />
        </mesh>

        {/* 內核外殼，營造光輝 */}
        <mesh scale={1.15}>
          <icosahedronGeometry args={[0.5, 2]} />
          <meshBasicMaterial color="#7FE8FF" transparent opacity={0.18} toneMapped={false} />
        </mesh>
      </group>
    </Float>
  );
}
