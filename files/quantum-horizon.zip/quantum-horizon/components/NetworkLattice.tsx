"use client";

import { useLayoutEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

import { usePerformance } from "./PerformanceGuard";

/* ---------------------------------------------------------------------
   NetworkLattice
   ---------------------------------------------------------------------
   立體網格節點 + 連線，作為「網絡」章節主視覺。
   使用 InstancedMesh 維持單次 draw call，加上 LineSegments 連線。
   --------------------------------------------------------------------- */

interface NetworkLatticeProps {
  scrollRef: React.MutableRefObject<{ progress: number }>;
}

export default function NetworkLattice({ scrollRef }: NetworkLatticeProps) {
  const { tier } = usePerformance();
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const linesRef = useRef<THREE.LineSegments>(null);
  const groupRef = useRef<THREE.Group>(null);

  const nodeCount = tier === "ultra" ? 80 : tier === "high" ? 60 : 40;

  /* 隨機節點位置 */
  const { positions, lineGeometry } = useMemo(() => {
    const pos: THREE.Vector3[] = [];
    for (let i = 0; i < nodeCount; i++) {
      pos.push(
        new THREE.Vector3(
          (Math.random() - 0.5) * 8,
          (Math.random() - 0.5) * 5,
          (Math.random() - 0.5) * 8
        )
      );
    }

    // 計算近鄰連線（每點連最近 2 個）
    const linePositions: number[] = [];
    for (let i = 0; i < pos.length; i++) {
      const distances = pos
        .map((p, j) => ({ d: pos[i].distanceTo(p), j }))
        .filter((x) => x.j !== i)
        .sort((a, b) => a.d - b.d);

      for (let k = 0; k < 2; k++) {
        const target = pos[distances[k].j];
        linePositions.push(pos[i].x, pos[i].y, pos[i].z);
        linePositions.push(target.x, target.y, target.z);
      }
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute(
      "position",
      new THREE.Float32BufferAttribute(linePositions, 3)
    );

    return { positions: pos, lineGeometry: geo };
  }, [nodeCount]);

  /* 設置 instance matrix（在 ref 掛載後） */
  useLayoutEffect(() => {
    if (!meshRef.current) return;
    const dummy = new THREE.Object3D();
    positions.forEach((p, i) => {
      dummy.position.copy(p);
      dummy.scale.setScalar(0.04 + Math.random() * 0.04);
      dummy.updateMatrix();
      meshRef.current!.setMatrixAt(i, dummy.matrix);
    });
    meshRef.current.instanceMatrix.needsUpdate = true;
  }, [positions]);

  useFrame((state, delta) => {
    if (!groupRef.current) return;
    const t = state.clock.elapsedTime;
    const scroll = scrollRef.current.progress;

    groupRef.current.rotation.y += delta * 0.06;
    groupRef.current.rotation.x = Math.sin(t * 0.2) * 0.08;

    // 章節 2（網絡）顯示，其餘隱藏
    const visibility = Math.exp(-Math.pow((scroll - 0.66) * 5.0, 2));
    const targetScale = 0.5 + visibility * 0.7;
    groupRef.current.scale.lerp(
      new THREE.Vector3(targetScale, targetScale, targetScale),
      0.06
    );

    // 線條呼吸感
    if (linesRef.current && linesRef.current.material instanceof THREE.LineBasicMaterial) {
      linesRef.current.material.opacity = 0.12 + Math.sin(t * 0.6) * 0.05 + visibility * 0.2;
    }
  });

  return (
    <group ref={groupRef} position={[0, 0, 0]}>
      {/* 節點：白色發光球 */}
      <instancedMesh
        ref={meshRef}
        args={[undefined, undefined, nodeCount]}
        frustumCulled={false}
      >
        <sphereGeometry args={[1, 16, 16]} />
        <meshBasicMaterial color="#7FE8FF" toneMapped={false} />
      </instancedMesh>

      {/* 連線 */}
      <lineSegments ref={linesRef} geometry={lineGeometry} frustumCulled={false}>
        <lineBasicMaterial
          color="#5CA8FF"
          transparent
          opacity={0.18}
          toneMapped={false}
        />
      </lineSegments>
    </group>
  );
}
