/// <reference types="next" />
/// <reference types="next/image-types/global" />

// =====================================================================
// 著色器檔案模組宣告
// 在 next.config.mjs 中我們把 .glsl / .vert / .frag 設為 asset/source，
// 這裡告訴 TypeScript 它們會被 import 為 string。
// =====================================================================
declare module "*.glsl" {
  const content: string;
  export default content;
}
declare module "*.vert" {
  const content: string;
  export default content;
}
declare module "*.frag" {
  const content: string;
  export default content;
}
declare module "*.vs" {
  const content: string;
  export default content;
}
declare module "*.fs" {
  const content: string;
  export default content;
}
